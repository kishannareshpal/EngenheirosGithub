// Initialize Firebase
var config = {
  apiKey: "AIzaSyBsqI-AGvHpvdaDyvMQhSJJE9Pt01VgN5c",
  databaseURL: "https://examesproject.firebaseio.com",
  projectId: "examesproject",
};
firebase.initializeApp(config);

var rawThisName = document.getElementById("thisName").innerHTML;
var thisName = rawThisName.split(" ")[2];

$(document).ready(function()
 {


  var rootRef = firebase.database().ref( thisName + "/");
  var table = $('#table').on( 'processing.dt', function ( e, settings, processing ) {
      $('#processingIndicator').css( 'display', processing ? 'block' : 'none' );
    }).DataTable( {
      "bLengthChange": false,
      "bInfo": true,
      "processing": true,

      "language": {
      "url": "/datatable/portuguese.json"},
      "Processing": "a processar...",
      // "autoWidth": false,
      // "columnDefs": [
      //   { "width": "100%", "targets": 0 }
      // ],
      "columnDefs": [
                    {
                        className: 'mdl-data-table__cell--non-numeric'
                    }
                  ]
    });


// var dataset = [snap.child("name").val(), snap.val().Nombre];

rootRef.on("child_added", snap => {
  var dataSet = [snap.key, snap.val()];
  table.rows.add([dataSet]).draw();

  // console.log(dataSet);
  // console.log(snap.child());
  console.log(snap.val()); //This is the correct for values
  console.log(snap.key);
    //for the keys:


});
});
